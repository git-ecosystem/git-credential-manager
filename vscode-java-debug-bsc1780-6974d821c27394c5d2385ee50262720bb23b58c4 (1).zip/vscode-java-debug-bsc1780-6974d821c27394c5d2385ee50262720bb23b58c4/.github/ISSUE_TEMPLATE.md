[provide a description of the issue]

##### Environment
- Operating System:
- JDK version:
- Visual Studio Code version:
- Java extension version:
- Java Debugger extension version:

##### Steps To Reproduce
1. [step 1]
2. [step 2]

[attach a sample project reproducing the error]
[attach logs](https://github.com/redhat-developer/vscode-java/wiki/Troubleshooting#enable-logging)

##### Current Result

##### Expected Result

##### Additional Informations
