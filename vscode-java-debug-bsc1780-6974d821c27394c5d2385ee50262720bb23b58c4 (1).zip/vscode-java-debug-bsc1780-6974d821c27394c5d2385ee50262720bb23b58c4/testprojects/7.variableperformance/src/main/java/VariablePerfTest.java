public class VariablePerfTest {
    public static void main(String[] args) {
        new TooManyVariables().test();
    }
}