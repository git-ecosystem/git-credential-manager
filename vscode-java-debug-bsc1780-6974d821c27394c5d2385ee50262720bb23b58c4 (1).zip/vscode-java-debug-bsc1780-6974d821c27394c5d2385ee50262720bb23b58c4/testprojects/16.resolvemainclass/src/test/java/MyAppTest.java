
public class MyAppTest {

	public static void main(String agrsp[]) {
		System.out.println("Hello test App!");
	}
}