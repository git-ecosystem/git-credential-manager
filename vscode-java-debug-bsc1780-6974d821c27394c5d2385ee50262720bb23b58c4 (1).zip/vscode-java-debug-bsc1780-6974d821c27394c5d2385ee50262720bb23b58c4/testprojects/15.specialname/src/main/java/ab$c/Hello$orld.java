package ab$c;
public class Hello$orld {
    public static void main(String args[]) {
        System.out.println("Hello$orld");
    }
}