public class GradleTest {
    public static void main(String[] args) {
        System.out.println("This is a sample gradle project");
    }
}