package usersettings;

public class UserSettings {
    private static int number = 20;

    public static void main(String[] args) {

        String testName = "usersettings";
        System.out.println("Test name is " + testName + " and the test number is " + number);

    }

}
