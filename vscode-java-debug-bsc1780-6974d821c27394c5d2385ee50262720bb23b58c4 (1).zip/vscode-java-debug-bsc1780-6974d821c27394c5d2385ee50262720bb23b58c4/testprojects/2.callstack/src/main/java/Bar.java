public class Bar {
    public void testBar(int i) {
        System.out.println("This is test method in bar.");
    }
}
