module com.microsoft.app.mymodule {
    requires gson;
    requires java.base;
    requires java.sql;
    opens com.microsoft.app;
}