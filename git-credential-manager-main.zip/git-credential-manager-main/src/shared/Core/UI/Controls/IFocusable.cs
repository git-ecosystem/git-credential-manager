namespace GitCredentialManager.UI.Controls
{
    public interface IFocusable
    {
        void SetFocus();
    }
}
