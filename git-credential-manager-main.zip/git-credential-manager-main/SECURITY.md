# Security

If you discover a security issue in this repo, please submit it through the
[GitHub Security Bug Bounty][hackerone-github]

Thanks for helping make GitHub products safe for everyone.

[hackerone-github]: https://hackerone.com/github
